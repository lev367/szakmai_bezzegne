﻿using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace epitmenyado
{
    internal class Program
    {
        struct adat
        {
            public int adoszam;
            public string utca;
            public string hazszam;
            public string adosav;
            public int alapterulet;
        }

        static (int A, int B, int C) beolvas(List<adat> a)
        {
            using StreamReader f = new StreamReader("utca.txt", Encoding.Default);
            string elsosor = f.ReadLine();
            string[] es = elsosor.Split(' ');
            int A = int.Parse(es[0]);
            int B = int.Parse(es[1]);
            int C = int.Parse(es[2]);

            while (!f.EndOfStream)
            {
                string sor = f.ReadLine();
                string[] s = sor.Split(' ');
                adat seged = new adat
                {
                    adoszam = int.Parse(s[0]),
                    utca = s[1],
                    hazszam = s[2],
                    adosav = s[3],
                    alapterulet = int.Parse(s[4])
                };
                a.Add(seged);
            }

            return (A, B, C);
        }

        static void masodikfeladat(List<adat> a)
        {
            Console.WriteLine("2. feladat");
            int db = a.Count;
            Console.WriteLine("A mintában {0} telek szerepel", db);
        }
        static void harmadikfeladat(List<adat> a)
        {
            Console.WriteLine("3. feladat");
            Console.WriteLine("Egy tulajdonos adószáma: ");
            int megadottadoszam = int.Parse(Console.ReadLine());
            int x = 0;
            for (int i = 0; i < a.Count; i++)
            {
                if (a[i].adoszam == megadottadoszam)
                {
                    x++;
                    Console.WriteLine($"{a[i].utca} {a[i].hazszam}");
                }
            }
            if (x == 0)
            {
                Console.WriteLine("Nem szerepel az adatállományban.");
            }
        }
        static int ado(int adosav, int alapterulet)
        {
            int fizetendoado = adosav*alapterulet;
            return fizetendoado;
        }
        static void otodikfeladat(List<adat> a, int A, int B, int C)
        {
            Console.WriteLine("5. feladat");
            int Asav = a.Count(x => x.adosav == "A");
            int AsavAdo = 0;
            int Bsav = a.Count(x => x.adosav == "B");
            int BsavAdo = 0;
            int Csav = a.Count(x => x.adosav == "C");
            int CsavAdo = 0;
            for (int i = 0; i < a.Count; i++)
            {
                if (a[i].adosav=="A")
                {
                    AsavAdo = AsavAdo + ado(A, a[i].alapterulet);
                }
                if (a[i].adosav == "B")
                {
                    BsavAdo = BsavAdo + ado(B, a[i].alapterulet);
                }
                if (a[i].adosav == "C")
                {
                    CsavAdo = CsavAdo + ado(C, a[i].alapterulet);
                }
            }
            Console.WriteLine("A sávban {0} telek esik, az adó {1} Ft.", Asav, AsavAdo);
            Console.WriteLine("A sávban {0} telek esik, az adó {1} Ft.", Bsav, BsavAdo);
            Console.WriteLine("A sávban {0} telek esik, az adó {1} Ft.", Csav, CsavAdo);
        }
        static void hatodikfeladat(List<adat> a)
        {
            Console.WriteLine("6. feladat");
            Console.WriteLine("Több sávba sorolt utcák");
            List<string> utcak = new List<string>();
            for (int i = 0; i < a.Count; i++)
            {
                string utca = a[i].utca;
                List<string> adosavok = new List<string>();
                adosavok.AddRange(a.Where(x => x.utca == utca).Select(x => x.adosav).Distinct().ToList());
                if (adosavok.Count > 1 && !utcak.Contains(utca))
                {
                    utcak.Add(utca);
                    Console.WriteLine(utca);
                }

            }
        }
        static void hetedikfeladat(List<adat> a, int A, int B, int C)
        {
            StreamWriter f = new StreamWriter("adosok.txt");
            List<int> adosok = new List<int>();
            for (int i = 0; i < a.Count; i++)
            {
                int fizetendoado = 0;
                int ados = a[i].adoszam;
                if (!adosok.Contains(ados)) 
                {
                    adosok.Add(ados);
                    List<adat> adostelkei = new List<adat>();
                    for (int x = 0; x < a.Count; x++)
                    {
                        if (a[x].adoszam==ados)
                        {
                            adostelkei.Add(a[x]);
                        }
                    }
                    for (int j = 0; j < adostelkei.Count(); j++)
                    {
                        if (adostelkei[j].adosav == "A")
                        {
                            fizetendoado = fizetendoado + ((adostelkei[j].alapterulet) * A);
                        }
                        if (adostelkei[j].adosav == "B")
                        {
                            fizetendoado = fizetendoado + ((adostelkei[j].alapterulet) * B);
                        }
                        if (adostelkei[j].adosav == "C")
                        {
                            fizetendoado = fizetendoado + ((adostelkei[j].alapterulet) * C);
                        }
                    }
                    adostelkei.Clear();
                }
                f.WriteLine($"{ados} {fizetendoado}");
                adosok.Clear();
            }

            f.Close();
        }

        static void Main(string[] args)
        {
            List<adat> hazak = new List<adat>();
            var (A, B, C) = beolvas(hazak);
            masodikfeladat(hazak);
            harmadikfeladat(hazak);
            otodikfeladat(hazak, A, B, C);
            hatodikfeladat(hazak);
            hetedikfeladat(hazak, A, B, C);
        }
    }
}