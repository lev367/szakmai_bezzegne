﻿using System.Text;

namespace telefonszamla
{
    internal class Program
    {
        struct adat
        {
            public int kora;
            public int kperc;
            public int kmperc;
            public int vora;
            public int vperc;
            public int vmperc;
            public int telefonszam;
        }
        static void beolvas(List<adat> a)
        {
            StreamReader f = new StreamReader("HIVASOK.TXT", Encoding.Default);
            do
            {
                adat seged;
                string sor = f.ReadLine();
                string[] s = sor.Split(" ");
                seged.kora = int.Parse(s[0]);
                seged.kperc = int.Parse(s[1]);
                seged.kmperc = int.Parse(s[2]);
                seged.vora = int.Parse(s[3]);
                seged.vperc = int.Parse(s[4]);
                seged.vmperc = int.Parse(s[5]);
                string telefonszam = f.ReadLine();
                seged.telefonszam = int.Parse(telefonszam);
                a.Add(seged);
            } while (!f.EndOfStream);
            f.Close();
        }
        static void elsofeladat()
        {
            Console.WriteLine("1. Feladat:");
            Console.WriteLine("Adjon meg egy telefonszamot!");
            string? beolvasott = Console.ReadLine();
            if (string.IsNullOrEmpty(beolvasott))
            {
                Console.WriteLine("Nem adott meg telefonszámot.");
                return;
            }
            string hivoszam = beolvasott.Substring(0, 2);
            if (hivoszam == "39" || hivoszam == "41" || hivoszam == "71")
            {
                Console.WriteLine("Mobil"); ;
            }
            else
            {
                Console.WriteLine("Nem mobil"); ;
            }
        }
        static void masodikfeladat()
        {
            Console.WriteLine("2. Feladat:");
            Console.WriteLine("Adjon  meg egy hivas kezdeti es vegi idopontot (ora perc masodperc pl:'6 55 22 7 10 44'");
            adat bekert = new adat();
            string? beolvasott = Console.ReadLine();
            if (string.IsNullOrEmpty(beolvasott))
            {
                Console.WriteLine("Nem adott meg idopontot.");
                return;
            }
            string[] s = beolvasott.Split(" ");
            bekert.kora = int.Parse(s[0]);
            bekert.kperc = int.Parse(s[1]);
            bekert.kmperc = int.Parse(s[2]);
            bekert.vora = int.Parse(s[3]);
            bekert.vperc = int.Parse(s[4]);
            bekert.vmperc = int.Parse(s[5]);
            int idotartam = 0;
            if (bekert.kora == bekert.vora)
            {
                idotartam = (bekert.vperc - bekert.kperc);
            }

        }
        static void harmadikfeladat(List<adat> a)
        {
            StreamWriter sr = new StreamWriter("percek.txt");
            for (int i = 0; i < a.Count; i++)
            {
                int kezdmp = a[i].kora * 3600 + a[i].kperc * 60 + a[i].kmperc;
                int vegemp = a[i].vora * 3600 + a[i].vperc * 60 + a[i].vmperc;
                int hossz = vegemp - kezdmp;
                if (hossz < 0) hossz = 0;

                int perc = (hossz + 60) / 60;
                sr.WriteLine($"{perc} {a[i].telefonszam}");

            }
            sr.Close();
        }
        static void negyedikfeladat (List<adat> a)
        {
            Console.WriteLine("4.feladat");
            int csben = 0;
            int cskivul = 0;
            for (int i = 0; i < a.Count(); i++)
            {
                if (a[i].kora>=7 && a[i].kora <= 18)
                {
                    csben++;
                }
                else
                {
                    cskivul++;
                }
            }
            Console.WriteLine($"{csben} hívás volt csúcsidőben és {cskivul} hívács volt csúcsidőn kivül.");
        }
        static void otodikfeladat(List<adat> a)
        {
            Console.WriteLine("5.feladat");
            int mobil = 0;
            int vezetekes = 0;
            for (int i = 0; i < a.Count(); i++)
            {
                string hivoszam = (a[i].telefonszam).ToString();
                string fajta = hivoszam.Substring(0, 2);
                if (fajta == "39" || fajta == "41" || fajta == "71")
                {
                    int kezdmp = a[i].kora * 3600 + a[i].kperc * 60 + a[i].kmperc;
                    int vegemp = a[i].vora * 3600 + a[i].vperc * 60 + a[i].vmperc;
                    int hossz = vegemp - kezdmp;
                    if (hossz < 0) hossz = 0;

                    mobil = mobil + ((hossz + 60) / 60);
                    }
                else
                {
                    int kezdmp = a[i].kora * 3600 + a[i].kperc * 60 + a[i].kmperc;
                    int vegemp = a[i].vora * 3600 + a[i].vperc * 60 + a[i].vmperc;
                    int hossz = vegemp - kezdmp;
                    if (hossz < 0) hossz = 0;

                    vezetekes = vezetekes + ((hossz + 60) / 60);
                }
            }
            Console.WriteLine($"{mobil} percet beszélt a felhasználó mobilon és {vezetekes} percet vezetékesen");
        }
        static void hatodikfeladat (List<adat> a)
        {
            double mobil = 0;
            double vezetekes = 0;
            for (int i = 0; i < a.Count(); i++)
            {
                string hivoszam = (a[i].telefonszam).ToString();
                string fajta = hivoszam.Substring(0, 2);

                if (fajta == "39" || fajta == "41" || fajta == "71")
                {
                    int kezdmp = a[i].kora * 3600 + a[i].kperc * 60 + a[i].kmperc;
                    int vegemp = a[i].vora * 3600 + a[i].vperc * 60 + a[i].vmperc;
                    int hossz = vegemp - kezdmp;
                    if (a[i].kora >= 7 && a[i].kora <= 18)
                    {
                        mobil = mobil + (((hossz + 60) / 60) * 69.175);
                    }
                }
                else
                {
                    int kezdmp = a[i].kora * 3600 + a[i].kperc * 60 + a[i].kmperc;
                    int vegemp = a[i].vora * 3600 + a[i].vperc * 60 + a[i].vmperc;
                    int hossz = vegemp - kezdmp;
                    if (a[i].kora >= 7 && a[i].kora <= 18)
                    {
                        vezetekes = vezetekes + (((hossz + 60) / 60) * 30);
                    }
                }
            }
            double csucsdijashivasokara = mobil + vezetekes;
            Console.WriteLine($"{csucsdijashivasokara} kell fizetnie a felhsznalonak a csucsdijas hivasokert");
        }

        static void Main(string[] args)
        {
            List<adat> szamok = new List<adat>();
            beolvas(szamok);
            elsofeladat();
            masodikfeladat();
            harmadikfeladat(szamok);
            negyedikfeladat(szamok);
            otodikfeladat(szamok);
            hatodikfeladat(szamok);
        }
    }
}
