﻿using System.Text;
using System.Linq;
using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace sebesseg
{
    internal class Program
    {
        struct adat
        {
            public int elso;
            public string masodik;
        }
        static int beolvas(List<adat> a)
        {
            StreamReader f = new StreamReader("ut.txt", Encoding.Default);
            int uthossz = int.Parse(f.ReadLine());
            do
            {
                string sor = f.ReadLine();
                string[] s = sor.Split(" ");
                adat seged;
                seged.elso = int.Parse(s[0]);
                seged.masodik = s[1];

                a.Add(seged);
            } while (!f.EndOfStream);
            f.Close();
            return uthossz;
        }
        static void masodikfeladat(List<adat> a)
        {
            
            Console.WriteLine("2. Feladat:");
            Console.WriteLine("A települések neve:");
            var telepulesek = a.Where(x => (x.masodik).StartsWith("Varos"));
            foreach (var item in telepulesek)
            {
                Console.WriteLine(item.masodik);
            }
        }
        static void harmadikfeladat(List<adat> a)
        {
            Console.WriteLine("3. Feladat:");
            Console.Write("Adja meg a vizsgált szakasz hosszát km-ben! ");

            if (!double.TryParse(Console.ReadLine(), out double km))
            {
                Console.WriteLine("Érvénytelen szám. Kilépés a 3. feladatból.");
                return;
            }

            double szakaszMeters = km * 1000.0;
            List<int> sebessegLista = new List<int>();
            foreach (var adatok in a)
            {
                if (adatok.elso <= szakaszMeters)
                {
                    if (int.TryParse(adatok.masodik, out int seb))
                    {
                        sebessegLista.Add(seb);
                    }
                }
            }

            int legkisebb = sebessegLista.Min();
            Console.WriteLine("Az első {0} km-en a legalacsonyabb megengedett sebesség {1} km/h volt.", km, legkisebb);
        }

        static void negyedikfeladat(List<adat> a, int uthossz)
        {
            Console.WriteLine("4. Feladat:");

            int varosOsszHossz = 0;

            for (int i = 0; i < a.Count; i++)
            {
                if (a[i].masodik.StartsWith("Varos"))
                {
                    int start = a[i].elso;
                    for (int j = i + 1; j < a.Count; j++)
                    {
                        if (a[j].masodik == "]")
                        {
                            int end = a[j].elso;
                            varosOsszHossz += (end - start);
                            break;
                        }
                    }
                }
            }

            double szazalek = (double)varosOsszHossz / uthossz * 100.0;
            szazalek=Math.Round(szazalek, 2);
            Console.WriteLine("Az út {0} százaléka vezet településen belül.", szazalek);
        }
        static string Otodikfeladat(List<adat> a)
        {
            Console.WriteLine("5. Feladat:");
            Console.WriteLine("Adjon meg egy település nevét! ");
            string telepulesNev = Console.ReadLine();
            int telepulesHossz = 0;
            int sebKorlat = 0;
            for (int i = 0; i < a.Count; i++)
            {
                if (a[i].masodik == telepulesNev)
                {
                    int start = a[i].elso;
                    for (int j = i + 1; j < a.Count; j++)
                    {
                        if (int.TryParse(a[j].masodik, out int seb))
                        {
                            sebKorlat++;
                        }
                        if (a[j].masodik == "]")
                        {
                            int end = a[j].elso;
                            telepulesHossz += (end - start);
                            break;
                        }
                    }
                }
            }
            Console.WriteLine("A sebességkorlátozó táblák száma: " + sebKorlat);
            Console.WriteLine("Az út hossza a településen belül {0} méter.", telepulesHossz);
            return telepulesNev;
        }
        static void hatodikfeladat(List<adat> a, string telepules)
        {
            Console.WriteLine("6. feladat");
            string kozeliVaros1 = "";
            string kozeliVaros2 = "";
            int tavolsag1 = int.MaxValue;
            int tavolsag2 = int.MaxValue;
            for (int i = 0; i < a.Count; i++)
            {
                if (a[i].masodik == telepules)
                {
                    int start = 0;
                    for (int j = i + 1; j < a.Count; j++)
                    {
                        if (a[j].masodik == "]")
                        {
                            start = a[j].elso;
                            break;
                        }
                    }
                    for (int j = i - 1; j >= 0; j=j-1)
                    {
                        int end1 = a[j].elso;
                        if (a[j].masodik.StartsWith("Varos"))
                        {
                            tavolsag1 = start - end1;
                            kozeliVaros1 = a[j].masodik;
                            break;
                        }
                    }
                    for (int j = i + 1; j < a.Count; j++)
                    {
                        int end2 = a[j].elso;
                        if (a[j].masodik.StartsWith("Varos"))
                        {
                            tavolsag2 = end2 - start;
                            kozeliVaros2 = a[j].masodik;
                            break;
                        }
                    }
                }
            }
            if (tavolsag1 > tavolsag2)
            {
                Console.WriteLine("A legközelebbi település: " + kozeliVaros2);
            }
            if (tavolsag1 < tavolsag2)
            {
                Console.WriteLine("A legközelebbi település: " + kozeliVaros1);
            }
            if (tavolsag1 == tavolsag2)
            {
                Console.WriteLine("A legközelebbi települések: " + kozeliVaros1);
            }
        }

        static void Main(string[] args)
        {
            List<adat> versenyok = new List<adat>();
            int uthossz = beolvas(versenyok);
            masodikfeladat(versenyok);
            harmadikfeladat(versenyok);
            negyedikfeladat(versenyok, uthossz);
            string telepulesNev = Otodikfeladat(versenyok);
            hatodikfeladat(versenyok, telepulesNev);
        }
    }
}
