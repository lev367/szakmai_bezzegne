﻿using System.Text;
using System.Linq;
using System.Collections.Immutable;
using System.Runtime.InteropServices;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;

namespace meterologia
{
    internal class Program
    {
        struct adat
        {
            public string telepules;
            public int ido;
            public string szel;
            public int homerseklet; 
        }
        static void beolvas(List<adat> a)
        {
            StreamReader f = new StreamReader("tavirathu13.txt", Encoding.Default);
            do
            {
                string sor = f.ReadLine();
                string[] s = sor.Split(" ");
                adat seged;
                seged.telepules = s[0];
                seged.ido = int.Parse(s[1]);
                seged.szel = s[2];
                seged.homerseklet = int.Parse(s[3]);
                a.Add(seged);
            } while (!f.EndOfStream);
            f.Close();
        }
        static void masodikfeladat(List<adat> a)
        {

            Console.WriteLine("2. Feladat:");
            Console.WriteLine("Adja meg egy település kódját! Település: ");
            string telepules=Console.ReadLine();
            List<adat> szures = a.Where(x => x.telepules == telepules).ToList();
            szures.Sort((x, y) => y.ido.CompareTo(x.ido));
            if (szures.Count > 0)
            {
                int ido=szures[0].ido;
                int ora = ido / 100;
                int perc = ido % 100;
                Console.WriteLine("Az utolsó mérési adat a megadott településről {0}:{1}-kor érkezett.", ora, perc);
            }
        }
        static void harmadikfeladat(List<adat> a)
        {
            Console.WriteLine("3. Feladat:");
            List<adat> legalacsonyabb = a.Where(x => x.homerseklet == a.Min(y => y.homerseklet)).ToList();
            if (legalacsonyabb.Count > 0)
            {
                int ido = legalacsonyabb[0].ido;
                int ora = ido / 100;
                int perc = ido % 100;
                Console.WriteLine("legalacsonyabb hőmérséklet: {0} {1}:{2} {3} fok.", legalacsonyabb[0].telepules, ora, perc, legalacsonyabb[0].homerseklet);
            }
            List<adat> legmagasabb=a.Where(x => x.homerseklet == a.Max(y => y.homerseklet)).ToList();
            if (legmagasabb.Count > 0)
            {
                int ido = legmagasabb[0].ido;
                int ora = ido / 100;
                int perc = ido % 100;
                Console.WriteLine("legmagasbb hőmérséklet: {0} {1}:{2} {3} fok.", legmagasabb[0].telepules, ora, perc, legmagasabb[0].homerseklet);
            }
        }
        static void negyedikfeladat(List<adat> a)
        {
            Console.WriteLine("4. Feladat:");
            List<adat> szelcsend= a.Where(x => x.szel == "00000").ToList();
            if (szelcsend.Count > 0)
            {
                foreach (var item in szelcsend)
                {
                    int ido = item.ido;
                    int ora = ido / 100;
                    int perc = ido % 100;
                    Console.WriteLine("{0} {1}:{2}", item.telepules, ora, perc);
                }
            }
            else
            {
                Console.WriteLine("Nem volt szélcsende a mérések idején.");
            }
        }
        static void otodikfeladat(List<adat> a)
        {
            Console.WriteLine("5. Feladat:");
            List<string> telepulesek = a.Select(x => x.telepules).Distinct().ToList();
            for (int i = 0; i < telepulesek.Count; i++)
            {
                int kozephomerseklet = 0;
                int db = 0;
                bool ora1 = false;
                bool ora7 = false;
                bool ora13 = false;
                bool ora19 = false;
                for (int j = 0; j < a.Count; j++) {
                    int ido = a[j].ido;
                    int ora = ido / 100;
                    if (telepulesek[i] == a[j].telepules && (ora==1 || ora==7 || ora==13 || ora==19)) {
                        db++;
                        kozephomerseklet += a[j].homerseklet;
                    }
                    if (telepulesek[i] == a[j].telepules)
                    {
                        if (ora == 1) ora1 = true;
                        if (ora == 7) ora7 = true;
                        if (ora == 13) ora13 = true;
                        if (ora == 19) ora19 = true;
                    }
                }
                bool megfelel = ora1 && ora7 && ora13 && ora19;

                int legmagasabb = a.Where(x => x.telepules == telepulesek[i]).Max(y => y.homerseklet);
                int legalacsonyabb = a.Where(x => x.telepules == telepulesek[i]).Min(y => y.homerseklet);
                int hoingadozas = legmagasabb - legalacsonyabb;

                if (megfelel == true)
                {
                    kozephomerseklet /= db;
                    Console.WriteLine("{0} Középhőmérséklet: {1}; Hőmérséklet-ingadozás: {2}", telepulesek[i], kozephomerseklet, hoingadozas);
                }
                else
                {
                    Console.WriteLine("{0} NA;  Hőmérséklet-ingadozás: {1}", telepulesek[i], hoingadozas);
                }
            }
        }
        static void hatodikfeladat(List<adat> a)
        {
            Console.WriteLine("6. Feladat:");
            List<string> telepulesek = a.Select(x => x.telepules).Distinct().ToList();
            foreach (var telepules in telepulesek)
            {
                string filename = telepules + ".txt";
                using (var f = new StreamWriter(filename, false, Encoding.Default))
                {
                    List<adat> records = a.Where(x => x.telepules == telepules).ToList();
                    records = records.OrderBy(x => x.ido).ToList();
                    f.WriteLine(telepules);
                    for (int i = 0; i < records.Count; i++)
                    {
                        string szel = (records[i].szel);
                        string szelero = szel[^2..]; 
                        int szelerosseg=int.Parse(szelero);
                        string keresztel = new string('#', szelerosseg);
                        int ido = records[i].ido;
                        int ora = ido / 100;
                        int perc = ido % 100;
                        f.WriteLine("{0}:{1} {2}", ora, perc, keresztel);
                    }
                }
                
            }
            Console.WriteLine("A fájlok elkészültek.");
            
        }


        static void Main(string[] args)
        {
            List<adat> meterologia = new List<adat>();
            beolvas(meterologia);
            masodikfeladat(meterologia);
            harmadikfeladat(meterologia);
            negyedikfeladat(meterologia);
            otodikfeladat(meterologia);
            hatodikfeladat(meterologia);
        }
    }
}
