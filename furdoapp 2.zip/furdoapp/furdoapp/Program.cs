﻿using System.Text;

namespace SzegediFurdo
{
    internal class Program
    {
        struct adat
        {
            public string kategoria;
            public int ar;
            public string idoszak;
        }
        static void beolvas(List<adat> a)
        {
            StreamReader f = new StreamReader("furdo.csv", Encoding.Default);
            f.ReadLine();
            do
            {
                string sor = f.ReadLine();
                string[] s = sor.Split(";");
                adat seged;
                seged.kategoria = s[0];
                seged.ar = int.Parse(s[1]);
                seged.idoszak = s[2];

                a.Add(seged);
            } while (!f.EndOfStream);
            f.Close();
        }
        static void harmas(List<adat> a)
        {
            int lehetoseg=a.Count;
            Console.WriteLine("3. feladat: {0}-féle lehetőség közül választhatnak a vendégek.", lehetoseg);
        }
        static void negyes(List<adat> a)
        {
            int ossz = 0;
            int db = 0;
            for (int i = 0; i < a.Count; i++)
            {
                if (a[i].kategoria.Contains("Felnott"))
                {
                    ossz += a[i].ar;
                    db++;
                }
            }
            int atlag = ossz / db;
            Console.WriteLine("4. feladat: A felnőtt belépőjegyel átlagára: {0}", atlag);
        }
        static void otos(List<adat> a)
        {
            Console.WriteLine("8. feladat: Családi jegyek két felnőtt kísérővel:");
            for (int i = 0; i < a.Count; i++)
            {
                if (a[i].kategoria.StartsWith("Csaladi-2"))
                {
                    Console.WriteLine("\t {0}, {1} Ft", a[i].kategoria, a[i].ar);
                }
            }
        }
        static void hatos(List<adat> a)
        {
            Console.WriteLine("6. feladat: Belépőjegy-lejetőségek száma napszakok szerint:");
            string belepo = "";
            List<string> lista = new List<string>();
            for (int i = 0; i < a.Count; i++)
            {
                int db = 0;
                belepo = a[i].idoszak;
                if (!lista.Contains(belepo))
                {
                    lista.Add(belepo);
                    for (int j = 0; j < a.Count; j++)
                    {
                        if (belepo == a[j].idoszak)
                        {
                            db++;
                        }
                    }
                    if (belepo == "EN")
                    {
                        Console.WriteLine("\t Egész napos: {0}", db);
                    }
                    else
                    {
                        Console.WriteLine("\t {0} órás: {1}", belepo, db);
                    }
                    
                }

            }
        }
        static void Main(string[] args)
        {
            List<adat> furdo = new List<adat>();
            beolvas(furdo);
            harmas(furdo);
            negyes(furdo);
            otos(furdo);
            hatos(furdo);
            Console.ReadKey();
        }
    }
}