﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace autoapp
{
    internal class Program
    {
        struct adat
        {
            public int sorszam;
            public string marka;
            public string modell;
            public int gyartasiev;
            public string szin;
            public int eladottdb;

        }
        static void beolvas(List<adat> a)
        {
            StreamReader f = new StreamReader("autok.csv", Encoding.Default);
            f.ReadLine();
            do
            {
                string sor = f.ReadLine();
                string[] s = sor.Split(";");
                adat seged;
                seged.sorszam = int.Parse(s[0]);
                seged.marka = s[1];
                seged.modell = s[2];
                seged.gyartasiev = int.Parse(s[3]);
                seged.szin = s[4];
                seged.eladottdb = int.Parse(s[5]);

                a.Add(seged);
            } while (!f.EndOfStream);
            f.Close();
        }
        static void otodikf(List<adat> a)
        {
            Console.WriteLine("5. Feladat: {0} autó található a listában", a.Count);
        }
        static void hatodikf(List<adat> a)
        {
            double osszatlag = 0;
            for (int x = 0; x < a.Count; x++)
            {
                osszatlag=osszatlag+a[x].eladottdb;
            }
            double atlag = osszatlag/a.Count;
            atlag = Math.Round(atlag, 1);
            Console.WriteLine("6. Feladat: Az autók esetében az átlagosan eladott darabszám {0}", atlag);
        }
        static void hetedikf(List<adat> a)
        {
            Console.WriteLine("7. feladat: Az elmúlt 5 évben gyártott autók:");
            for (int x = 0; x < a.Count; x++)
            {
                if (a[x].gyartasiev >= 2019)
                {
                    Console.WriteLine(" - {0}{1}: {2}", a[x].marka, a[x].modell, a[x].gyartasiev);
                }
            }
        }
        static void nyolcadikf(List<adat> a)
        {
            Console.WriteLine("8.feladat: Legsikeresebb márkák listája az eladott darabszám alapján:");
            for (int x = 0; x < a.Count; x++)
            {
                int markadb = 0;
                string marka = a[x].marka;
                for (int p = 0; p < a.Count; p++)
                {
                    if (marka == a[p].marka)
                    {
                        markadb = markadb + a[p].eladottdb;
                    }
                }
                Console.WriteLine(" - {0}: {1} darab", marka, markadb);
            }
        }
        static void Main(string[] args)
        {
            List<adat> auto = new List<adat>();
            beolvas(auto);
            otodikf(auto);
            hatodikf(auto);
            hetedikf(auto);
            nyolcadikf(auto);
            Console.ReadKey();
        }
    }
}
