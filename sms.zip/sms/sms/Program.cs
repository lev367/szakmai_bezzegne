﻿using System;
using System.Linq;
using System.Reflection;
using System.Text;

namespace sms
{
    internal class Program
    {
        struct adat
        {
            public string szo;

        }
        static void szobeolvas(List<adat> a)
        {
            StreamReader f = new StreamReader("szavak.txt", Encoding.Default);
            do
            {
                adat seged;
                seged.szo = f.ReadLine();
                a.Add(seged);
            } while (!f.EndOfStream);
            f.Close();
        }
        struct kodok
        {
            public string kod;
        }
        static void kodbeolvas(List<kodok> a)
        {
            StreamReader f = new StreamReader("kodok.txt", Encoding.Default);
            do
            {
                kodok seged;
                seged.kod= f.ReadLine();
                a.Add(seged);
            } while (!f.EndOfStream);
            f.Close();
        }
        static void elsofeladat(List<adat> a, List<string> b)
        {
            Console.WriteLine("\n 1.feladat");
            Console.WriteLine("Adjon meg egy betűt: ");
            string megadott = Console.ReadLine().ToUpper();
            for (int i = 0; i < b.Count(); i++)
            {
                if (b[i].Contains(megadott))
                {
                    int szam = i + 2;
                    Console.WriteLine(szam + " kód tartozik a megadott betűhöz");
                }
            }
        }
        static void masodikfeladat(List<adat> a, List<string> b)
        {
            Console.WriteLine("\n 2.feladat");
            Console.WriteLine("Adjon meg egy szót: ");
            string megadott = Console.ReadLine().ToUpper();
            char[] x = megadott.ToCharArray();
            Console.WriteLine("A következő kóddal lehet bevinni a telefonba: ");
            for (int i = 0; i < b.Count(); i++)
            {
                for (int j = 0; j < x.Count(); j++)
                {
                    if (b[i].Contains(x[j]))
                    {
                        int szam = i + 2;
                        Console.Write(szam);
                    }
                }
                
            }
        }
        static void negyedikfeladat(List<adat> a)
        {
            Console.WriteLine("\n \n 4.feladat");
            string leghosszabb = "";
            int hossz = 0;
            for (int i = 0; i < a.Count; i++)
            {
                string szo = a[i].szo;
                int szohossz = szo.Length;
                if (szohossz>hossz)
                {
                    hossz = szohossz;
                }
            }
            bool folytat = true;
            while (folytat == true)
            {
                for (int i = 0; i < a.Count; i++)
                {
                    if (hossz == a[i].szo.Length)
                    {
                        Console.WriteLine("A leghosszabb szó: "+ a[i].szo);
                        folytat = false;
                    }
                }
            }
        }
        static void otodikfeladat(List<adat> a)
        {
            Console.WriteLine("\n 5.feladat");
            int roviddb = 0;
            for (int i = 0; i < a.Count(); i++)
            {
                if (a[i].szo.Length<=5)
                {
                    roviddb++;
                }
            }
            Console.WriteLine($"{roviddb} rövid szó található.");
        }
        static void hatodikfeladat(List<adat> a, List<string> b)
        {
            
            StreamWriter f = new StreamWriter("kodok.txt");
            for (int i = 0; i < a.Count; i++)
            {
                List<int> kod = [];
                string sor = a[i].szo.ToUpper();
                char[] x = sor.ToCharArray();
                for (int y = 0; y < b.Count(); y++)
                {
                    for (int j = 0; j < x.Count(); j++)
                    {
                        if (b[y].Contains(x[j]))
                        {
                            int szam = y + 2;
                            kod.Add(szam);
                        }
                    }

                }
                foreach (var item in kod)
                {
                    f.Write(item);
                }
                f.WriteLine("");
            }
            f.Close();
        }
        static void hetedikfeladat(List<adat> a, List<kodok> c)
        {
            Console.WriteLine("\n 7.feladat");
            Console.WriteLine("Adjon meg egy számsort: ");
            string kod = Console.ReadLine();
            Console.Write("Lehetséges szavak: ");
            for (int i = 0; i < c.Count(); i++)
            {
                if (kod == c[i].kod)
                {
                    Console.Write(a[i].szo + ", ");
                }
            }
        }
        static void nyolcadikfeladat(List<adat> a, List<kodok> c, List<string> b)
        {
            Console.WriteLine("\n \n 8.feladat");
            List<string> tobbszoroskodok = [];
            for (int i = 0; i < c.Count; i++)
            {
                for (int j = i + 1; j < c.Count; j++)
                {
                    if (c[i].kod == c[j].kod && !tobbszoroskodok.Contains(c[i].kod))
                    {
                        tobbszoroskodok.Add(c[i].kod);
                    }
                }
            }
            
            for (int i = 0; i < a.Count(); i++)
            {
                List<int> szamkod = [];
                string nagybetuszo = a[i].szo.ToUpper();
                char[] x = nagybetuszo.ToCharArray();
                for (int p = 0; p < b.Count(); p++)
                {
                    for (int j = 0; j < x.Count(); j++)
                    {
                        if (b[p].Contains(x[j]))
                        {
                            int szam = p + 2;
                            szamkod.Add(szam);
                        }
                    }

                }
                
                string stringkod = string.Concat(szamkod);
                if (tobbszoroskodok.Contains(stringkod))
                {
                    Console.Write($"{a[i].szo} : {stringkod}; ");
                }

            }
        }
        static void kilencedikfeladat(List<adat> a, List<kodok> c, List<string> b)
        {
            Console.WriteLine("\n \n 9.feladat");
            string legtobbkod = "";
            int koddb = 0;
            for (int i = 0; i < c.Count; i++)
            {
                int belsokoddb = 0;
                for (int j = i+1; j < c.Count; j++)
                {
                    if (c[i].kod == c[j].kod)
                    {
                        belsokoddb++;
                    }
                }
                if (belsokoddb>koddb)
                {
                    koddb = belsokoddb;
                }
            }
            for (int i = 0; i < c.Count; i++)
            {
                int belsokoddb = 0;
                for (int j = i + 1; j < c.Count; j++)
                {
                    if (c[i].kod == c[j].kod)
                    {
                        belsokoddb++;
                    }
                }
                if (belsokoddb == koddb)
                {
                    legtobbkod = c[i].kod;
                }
            }
            Console.WriteLine("A kód amihez a legtöbb szó tartozik: {0}", legtobbkod);
            Console.WriteLine("És a kódhoz tartozó szavak: ");
            for (int i = 0; i < c.Count(); i++)
            {
                if (legtobbkod == c[i].kod)
                {
                    Console.Write(a[i].szo + ", ");
                }
            }
        }
        
        static void Main(string[] args)
        {
            List<string> betuk = ["ABC", "DEF", "GHI", "JKL", "MNO", "PQRS", "TUV", "WXYZ"];
            List<adat> szavak = new List<adat>();
            szobeolvas(szavak);
            elsofeladat(szavak, betuk);
            masodikfeladat(szavak, betuk);
            negyedikfeladat(szavak);
            otodikfeladat(szavak);
            hatodikfeladat(szavak, betuk);
            List<kodok> kodok = new List<kodok>();
            kodbeolvas(kodok);
            hetedikfeladat(szavak, kodok);
            nyolcadikfeladat(szavak, kodok, betuk);
            kilencedikfeladat(szavak, kodok, betuk);
        }
    }
}
