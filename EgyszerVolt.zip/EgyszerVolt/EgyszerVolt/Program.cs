﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.WebSockets;
using System.Text;

namespace EgyszerVolt
{
    internal class Program
    {
        struct adat
        {
            public string cim;
            public int hossz;
            public int ev;
            public string mufaj;
            public string dij;
        }
        static void beolvas(List<adat> a)
        {
            StreamReader f = new StreamReader("mesefilmek.csv", Encoding.Default);
            f.ReadLine();
            do
            {
                string sor = f.ReadLine();
                string[] s = sor.Split(";");
                adat seged;
                seged.cim = s[0];
                seged.hossz = int.Parse(s[1]);
                seged.ev = int.Parse(s[2]);
                seged.mufaj = s[3];
                seged.dij = s[4];

                a.Add(seged);
            } while (!f.EndOfStream);
            f.Close();
            Console.WriteLine("1-2. feladat: az adatszerkezet kész, az adatok beolvasása megtörtént.");
        }
        static void harmadik(List<adat> a)
        {
            Console.WriteLine("3. feladat: {0} mesefilm adatait tartalmazza az állomány.", a.Count);
        }
        static (int ora, int perc) negyedik(int hossz)
        {
            int ora = hossz / 60;
            int perc = hossz % 60;
            return (ora, perc);
        }
        static string otodik(List<adat> a)
        {
            bool x = true;
            string bemese = "";
            Console.WriteLine("Adja meg egy mese címét:");
            bemese=Console.ReadLine();
            while (x == true)
            {
                for (int i = 0; i < a.Count; i++)
                {
                    if (bemese != "")
                    {
                        x = false;
                    }
                    else
                    {
                        Console.WriteLine("Adja meg egy mese címét:");
                        bemese = Console.ReadLine();
                    }
                }
            }
            return (bemese);
        }
        static void hatodik(List<adat> a, string bekert)
        {
            int hossz = 137;
            bool x = false;
            for (int i = 0; i < a.Count; i++)
            {
                if (bekert == a[i].cim)
                {
                    hossz = a[i].hossz;
                    x = true;
                }
            }
            if (x == true)
            {
                (int ora, int perc) = negyedik(hossz);
                Console.WriteLine("6.Feladat: {0} óra {1} perc", ora, perc);
            }
            if (x == false)
            {
                Console.WriteLine("Nincs ilyen mesefilm");
            }
        }
        static void hetedik(List<adat> a)
        {
            List<string> b = new List<string>();
            Console.WriteLine("7.Feladat:");
            Console.WriteLine("2010 és 2020 között bemutatott mesefilmek:");
            for(int i = 0;i < a.Count; i++)
            {
                if (a[i].ev>=2010 && a[i].ev <= 2020)
                {
                    b.Add(a[i].cim);
                }
            }
            b.Sort();
            foreach (string adat in b)
            {
                Console.WriteLine(adat);
            }
        }
        static void nyolcadik(List<adat> a)
        {
            Console.WriteLine("8.feladat:");
            string mufaj = "";
            List<string> lista = new List<string>();
            for (int i = 0; i < a.Count; i++)
            {
                int db = 0;
                mufaj =a[i].mufaj;
                if (!lista.Contains(mufaj))
                {
                    lista.Add(mufaj);
                    for (int j = 0; j < a.Count; j++)
                    {
                        if (mufaj == a[j].mufaj)
                        {
                            db++;
                        }
                    }
                    Console.WriteLine("{0}: {1}", mufaj,db);
                }

            }
        }
        static void kilencedik(List<adat> a)
        {
            StreamWriter f = new StreamWriter("dijazottak.txt");
            for (int i = 0; i < a.Count; i++) 
            {
                if (a[i].dij != "N")
                {
                    f.WriteLine("{0} {1}", a[i].cim, a[i].dij);
                }
            }
            f.Close();
            Console.WriteLine("9. feladat: A fájl elkészült.");
        }

        static void Main(string[] args)
        {
            List<adat> mese = new List<adat>();
            beolvas(mese);
            harmadik(mese);
            string bekert=otodik(mese);
            hatodik(mese, bekert);
            hetedik(mese);
            nyolcadik(mese);
            kilencedik(mese);
            Console.ReadKey();
        }
    }
}
