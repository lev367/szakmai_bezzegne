﻿using System.Text;
using System.Linq;
using System.Threading.Channels;

namespace sms_feladat
{
    internal class Program
    {
        struct Sms
        {
            public string kod;
        }
        public static string[] tomb1 = { "2abc", "3def", "4ghi", "5jkl", "6mno", "7pqrs", "8tuv", "9wxyz" };
        static string Vizsgálás(string s)
        {
            string seged = "";
            
            for (int i = 0; i < s.Length; i++)
            {
                for (int j = 0; j < tomb1.Length; j++)
                {
                    if (tomb1[j].Contains(s[i]))
                    {
                        seged+=tomb1[j][0];
                    }
                }
            }
            return seged;
        }
        static void Main(string[] args)
        {

            Console.WriteLine("Kérem adjon meg egy tetszőleges betűt az angol abc alapján: ");
            string valasz = Console.ReadLine();
            for (int i = 0; i < tomb1.Length; i++)
            {
                if (tomb1[i].Contains(valasz))
                {
                    Console.WriteLine(tomb1[i][0]);
                }
            }
            Console.WriteLine("Kérem adjon meg egy tetszőleges szót: ");
            string szo = Console.ReadLine();
            Console.WriteLine(Vizsgálás(szo));


            Console.WriteLine("");
            List<string> szavak = new List<string>();
            StreamReader r = new StreamReader("szavak.txt");
            while (!r.EndOfStream)
            {
                szavak.Add(r.ReadLine());
            }
            r.Close();
            //Console.WriteLine(szavak[0]);


            Console.WriteLine("4. feladat");
            int hossz = 0;
            string szohossz = "";
            for (int i = 0; i < szavak.Count; i++)
            {
                if (szavak[i].Length > hossz)
                {
                    hossz = szavak[i].Length;
                    szohossz = szavak[i];
                }
            }
            Console.WriteLine("");
            Console.WriteLine("A leghosszabb szó a(z) " + szohossz + ", terjedelme pedig: " + hossz);
            Console.WriteLine("5. feladat");
            int db = 0;
            for (int i = 0; i < szavak.Count; i++)
            {
                if (szavak[i].Length <= 5)
                {
                    db++;
                }
            }
            Console.WriteLine("");
            Console.WriteLine("Rövid szavak száma az állományban: {0}", db);

            Console.WriteLine("6. feladat");
            Console.WriteLine("Nyissa meg a .txt kiterjesztésű fájlt!");
            StreamWriter w = new StreamWriter("kodok.txt");
            List<string> kodok = new List<string>();

            for (int i = 0; i < szavak.Count; i++)
            {
                w.WriteLine(Vizsgálás(szavak[i]));
                kodok.Add(Vizsgálás(szavak[i]));
            }
            w.Close();

            Console.WriteLine("7. feladat");
            Console.WriteLine("Kérem adjon meg egy tetszőleges számsort: ");
            string szamsor = Console.ReadLine();
            Console.WriteLine("Az ön által választott számsorozathoz tartozó szó/szavak: ");
            for (int i = 0; i < kodok.Count; i++)
            {
                if (szamsor == kodok[i])
                {
                    Console.WriteLine(szavak[i]);
                }
            }
            Console.WriteLine("8. feladat");
            Dictionary<string, int> gyujtemeny = new Dictionary<string, int>();
            for (int i = 0; i < kodok.Count; i++)
            {
                if (gyujtemeny.ContainsKey(kodok[i]))
                {
                    gyujtemeny[kodok[i]]++;
                }
                else
                {
                    gyujtemeny[kodok[i]] = 1;
                }
            }
            foreach(var x in gyujtemeny)
            {
                if(x.Value > 1)
                { 
                    for (int i = 0; i < kodok.Count; i++)
                    {
                        if (x.Key == kodok[i])
                        {
                            Console.Write("{0}:{1}; ", x.Key, szavak[i]);
                        }
                    }
                }
            }
        }  
    }
}
 
